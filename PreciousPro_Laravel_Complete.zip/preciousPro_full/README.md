# 💎 PreciousPro — Jewelry Quality Assurance and Management System

## Quick Setup Guide

### Prerequisites
- PHP 8.2+
- Composer
- MySQL 8.0+
- Node.js 18+ & npm

---

### Installation Steps

```bash
# 1. Create a new Laravel 11 project
composer create-project laravel/laravel preciousPro
cd preciousPro

# 2. Install Laravel Breeze for auth scaffolding
composer require laravel/breeze --dev
php artisan breeze:install blade

# 3. Install Node dependencies and build assets
npm install && npm run build
```

### 2. Copy Project Files

Copy all files from this zip into your Laravel project root, **merging** (not replacing) directories:

- `app/`  → replaces/adds Models, Controllers, Middleware, Requests
- `database/` → adds migrations and seeders
- `resources/views/` → adds all Blade views
- `routes/web.php` → replaces the default routes file
- `bootstrap/app.php` → replaces to register CheckRole middleware

> ⚠️ Do NOT overwrite `composer.json`, `package.json`, or `.env`

---

### 3. Configure Environment

Edit your `.env` file:

```env
APP_NAME="PreciousPro"
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=preciousPro_db
DB_USERNAME=root
DB_PASSWORD=your_password
```

### 4. Database Setup

```bash
# Create the database first, then:
php artisan migrate

# Seed roles, default admin user, and jewelry categories
php artisan db:seed
```

### 5. Run the Application

```bash
php artisan serve
```

Visit: http://localhost:8000

---

## Default Login Credentials

| Field    | Value                        |
|----------|------------------------------|
| Email    | admin@preciousPro.com        |
| Password | Admin@12345                  |

> ⚠️ **Change the admin password immediately after first login!**

---

## System Roles

| Role               | Access                                      |
|--------------------|---------------------------------------------|
| Admin              | Full system access                          |
| Production Manager | Products, Categories, Production runs       |
| QC Officer         | Quality Inspections                         |
| Inventory Officer  | Inventory & Stock Transactions              |
| Finance Officer    | Finance Records                             |

---

## Project Structure (Files in this ZIP)

```
app/
  Http/
    Controllers/          — All 9 controllers
    Middleware/           — CheckRole.php (RBAC)
    Requests/             — 6 Form Request validators
  Models/                 — 9 Eloquent models

database/
  migrations/             — 9 migrations (dependency-ordered)
  seeders/                — DatabaseSeeder, RoleSeeder, UserSeeder, CategorySeeder

resources/views/
  layouts/app.blade.php   — Master layout with gold-themed sidebar
  dashboard.blade.php     — KPI dashboard with Chart.js
  products/               — index, create, edit views
  production/             — index view
  quality/                — index view
  inventory/              — index view
  finance/                — index view
  users/                  — index view

routes/
  web.php                 — All routes with role middleware

bootstrap/
  app.php                 — Middleware alias registration
```

---

## ERD Relationship Summary

```
roles ──< users
          ├──< quality_inspections (as inspector)
          ├──< stock_transactions (as processed_by)
          └──< finance_records (as recorded_by)

categories ──< products
               ├──< productions
               │    ├──< quality_inspections
               │    └──< finance_records
               └──< inventories
                    └──< stock_transactions
```

---

## Security Features

- ✅ Passwords hashed with bcrypt (Laravel `hashed` cast)
- ✅ CSRF tokens on all forms (`@csrf`)
- ✅ Server-side validation via Form Requests
- ✅ Role-based route protection via `CheckRole` middleware
- ✅ `inspector_id` / `recorded_by` always set from `auth()->id()`, never user input
- ✅ Self-deletion protection for users
- ✅ Stock Out validation prevents negative inventory
- ✅ DB transactions for multi-step operations
- ✅ Route model binding (auto 404 for invalid IDs)

@extends('layouts.app')
@section('title', 'Users')

@section('content')
<div class="page-header">
    <div><h2>User Management</h2><small>Manage system users and their roles</small></div>
    <a href="{{ route('users.create') }}" class="btn btn-gold"><i class="bi bi-person-plus me-1"></i> Add User</a>
</div>

<div class="data-card">
    <div class="data-card-header"><h5>System Users ({{ $users->total() }} total)</h5></div>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>{{ $user->id }}</td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div style="width:34px;height:34px;border-radius:50%;background:#D4AF37;display:flex;align-items:center;justify-content:center;color:white;font-weight:600;font-size:0.82rem">
                                {{ substr($user->full_name,0,1) }}
                            </div>
                            <strong>{{ $user->full_name }}</strong>
                            @if($user->id === auth()->id()) <span class="badge badge-gold">You</span> @endif
                        </div>
                    </td>
                    <td>{{ $user->email }}</td>
                    <td><span class="badge badge-pending">{{ $user->role?->role_name }}</span></td>
                    <td>
                        <div class="d-flex gap-2">
                            <a href="{{ route('users.edit', $user) }}" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                            @if($user->id !== auth()->id())
                            <form method="POST" action="{{ route('users.destroy', $user) }}" onsubmit="return confirm('Delete this user?')">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="5" class="text-center py-5 text-muted">No users found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="p-3">{{ $users->links() }}</div>
</div>
@endsection

<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUserRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->user()->hasRole('Admin');
    }

    public function rules(): array
    {
        $userId = $this->route('user')?->id;

        return [
            'full_name' => ['required', 'string', 'max:100'],
            'email'     => ['required', 'email', 'max:100', 'unique:users,email,' . $userId],
            'password'  => [$userId ? 'nullable' : 'required', 'string', 'min:8', 'confirmed'],
            'role_id'   => ['required', 'exists:roles,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'role_id.exists' => 'Selected role does not exist.',
            'email.unique'   => 'This email is already registered.',
            'password.min'   => 'Password must be at least 8 characters.',
        ];
    }
}

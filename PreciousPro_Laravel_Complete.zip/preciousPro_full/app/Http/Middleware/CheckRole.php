<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Check if the authenticated user has one of the allowed roles.
     * Usage in routes: ->middleware('role:Admin,QC Officer')
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        $userRole = auth()->user()->role?->role_name;

        if (!in_array($userRole, $roles)) {
            abort(403, 'Unauthorized action. Insufficient role permissions.');
        }

        return $next($request);
    }
}

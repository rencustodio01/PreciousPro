<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Inventory extends Model
{
    protected $fillable = ['product_id', 'quantity_available', 'last_updated'];

    protected $casts = ['last_updated' => 'datetime'];

    /** Inventory belongs to one product (Many-to-One) */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** Inventory has many stock transactions (One-to-Many) */
    public function stockTransactions(): HasMany
    {
        return $this->hasMany(StockTransaction::class);
    }
}

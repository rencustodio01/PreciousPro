<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Product extends Model
{
    protected $fillable = ['category_id', 'product_name', 'description', 'base_price', 'status'];

    protected $casts = ['base_price' => 'decimal:2'];

    /** Product belongs to one category (Many-to-One) */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /** Product can have many production runs (One-to-Many) */
    public function productions(): HasMany
    {
        return $this->hasMany(Production::class);
    }

    /** Product has one inventory record (One-to-One) */
    public function inventory(): HasOne
    {
        return $this->hasOne(Inventory::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Production extends Model
{
    protected $fillable = ['product_id', 'production_date', 'quantity_produced', 'status'];

    protected $casts = ['production_date' => 'date'];

    /** Production belongs to one product (Many-to-One) */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** Production has many quality inspections (One-to-Many) */
    public function qualityInspections(): HasMany
    {
        return $this->hasMany(QualityInspection::class);
    }

    /** Production has many finance cost records (One-to-Many) */
    public function financeRecords(): HasMany
    {
        return $this->hasMany(FinanceRecord::class);
    }

    /** Calculate total production cost */
    public function totalCost(): float
    {
        return (float) $this->financeRecords()->sum('amount');
    }
}

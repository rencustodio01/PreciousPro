<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Role extends Model
{
    protected $fillable = ['role_name', 'description'];

    /**
     * A role can be assigned to many users.
     * Relationship: roles → users (One-to-Many)
     */
    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}

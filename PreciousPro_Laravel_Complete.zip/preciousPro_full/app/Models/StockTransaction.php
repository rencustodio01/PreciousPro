<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockTransaction extends Model
{
    protected $fillable = ['inventory_id', 'transaction_type', 'quantity', 'transaction_date', 'processed_by'];

    protected $casts = ['transaction_date' => 'datetime'];

    /** Stock transaction belongs to one inventory record */
    public function inventory(): BelongsTo
    {
        return $this->belongsTo(Inventory::class);
    }

    /** Stock transaction was processed by one user */
    public function processor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'processed_by');
    }
}

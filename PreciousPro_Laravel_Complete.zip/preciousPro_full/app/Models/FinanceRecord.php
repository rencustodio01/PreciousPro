<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FinanceRecord extends Model
{
    protected $fillable = ['production_id', 'cost_type', 'amount', 'record_date', 'recorded_by'];

    protected $casts = ['record_date' => 'date', 'amount' => 'decimal:2'];

    /** Finance record linked to one production run (Many-to-One) */
    public function production(): BelongsTo
    {
        return $this->belongsTo(Production::class);
    }

    /** Finance record was entered by one user (Many-to-One) */
    public function recorder(): BelongsTo
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }
}

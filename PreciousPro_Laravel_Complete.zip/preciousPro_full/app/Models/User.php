<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    protected $fillable = ['full_name', 'email', 'password', 'role_id'];

    protected $hidden = ['password', 'remember_token'];

    protected $casts = ['password' => 'hashed'];

    /** User belongs to one role (Many-to-One) */
    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    /** User (QC Officer) can perform many inspections */
    public function inspections(): HasMany
    {
        return $this->hasMany(QualityInspection::class, 'inspector_id');
    }

    /** User can process many stock transactions */
    public function stockTransactions(): HasMany
    {
        return $this->hasMany(StockTransaction::class, 'processed_by');
    }

    /** User can record many finance entries */
    public function financeRecords(): HasMany
    {
        return $this->hasMany(FinanceRecord::class, 'recorded_by');
    }

    /** Check if the user has a specific role by name */
    public function hasRole(string $roleName): bool
    {
        return $this->role?->role_name === $roleName;
    }

    /** Check if user has any of the given roles */
    public function hasAnyRole(array $roles): bool
    {
        return in_array($this->role?->role_name, $roles);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class QualityInspection extends Model
{
    protected $fillable = ['production_id', 'inspector_id', 'inspection_date', 'result', 'remarks'];

    protected $casts = ['inspection_date' => 'date'];

    /** Inspection belongs to one production run (Many-to-One) */
    public function production(): BelongsTo
    {
        return $this->belongsTo(Production::class);
    }

    /** Inspection is performed by one user/QC Officer (Many-to-One) */
    public function inspector(): BelongsTo
    {
        return $this->belongsTo(User::class, 'inspector_id');
    }
}
